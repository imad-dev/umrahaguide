import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Drawer(
      child: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: AppTheme.primaryGreen,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.mosque,
                      size: 40,
                      color: AppTheme.primaryGreen,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Umrah Companion',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    isArabic ? 'دليلك لرحلة عمرة مباركة' : 'Your guide for a blessed journey',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'الرئيسية' : 'Home'),
              onTap: () {
                Navigator.pushReplacementNamed(context, '/home');
              },
            ),
            ListTile(
              leading: Icon(Icons.menu_book, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'الوحدات التعليمية' : 'Educational Modules'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/education');
              },
            ),
            ListTile(
              leading: Icon(Icons.mosque, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'مناسك العمرة' : 'Umrah Rituals'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/rituals');
              },
            ),
            ListTile(
              leading: Icon(Icons.luggage, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'أدوات السفر' : 'Travel Toolkit'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/travel_kit');
              },
            ),
            ListTile(
              leading: Icon(Icons.calendar_today, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'المخطط الشخصي' : 'Personal Planner'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/planner');
              },
            ),
            ListTile(
              leading: Icon(Icons.video_library, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'الوسائط المتعددة' : 'Multimedia'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/multimedia');
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.language, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'تغيير اللغة' : 'Change Language'),
              onTap: () {
                languageProvider.toggleLanguage();
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.settings, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'الإعدادات' : 'Settings'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/settings');
              },
            ),
            ListTile(
              leading: Icon(Icons.info, color: AppTheme.primaryGreen),
              title: Text(isArabic ? 'عن التطبيق' : 'About'),
              onTap: () {
                // Show about dialog
                showAboutDialog(
                  context: context,
                  applicationName: 'Umrah Companion',
                  applicationVersion: '1.0.0',
                  applicationIcon: Icon(
                    Icons.mosque,
                    color: AppTheme.primaryGreen,
                    size: 40,
                  ),
                  applicationLegalese: isArabic
                      ? 'دليل تعليمي وتفاعلي للمسلمين الذين يستعدون لأداء العمرة'
                      : 'An educational and interactive guide for Muslims preparing to perform Umrah',
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
