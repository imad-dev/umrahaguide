class AppRoutes {
  static const String splash = '/splash';
  static const String home = '/home';
  static const String education = '/education';
  static const String rituals = '/rituals';
  static const String travelKit = '/travel_kit';
  static const String planner = '/planner';
  static const String multimedia = '/multimedia';
  static const String settings = '/settings';
}
