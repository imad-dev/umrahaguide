import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class RitualsScreen extends StatefulWidget {
  const RitualsScreen({Key? key}) : super(key: key);

  @override
  _RitualsScreenState createState() => _RitualsScreenState();
}

class _RitualsScreenState extends State<RitualsScreen> {
  final List<Map<String, dynamic>> _rituals = [
    {
      'title_en': 'Ihram',
      'title_ar': 'الإحرام',
      'description_en': 'The sacred state of purity and devotion',
      'description_ar': 'حالة مقدسة من الطهارة والتفاني',
      'icon': Icons.person_outline,
      'route': '/rituals/ihram',
    },
    {
      'title_en': 'Tawaf',
      'title_ar': 'الطواف',
      'description_en': 'Circumambulation around the Kaaba',
      'description_ar': 'الطواف حول الكعبة',
      'icon': Icons.sync,
      'route': '/rituals/tawaf',
    },
    {
      'title_en': 'Sa\'i',
      'title_ar': 'السعي',
      'description_en': 'Walking between Safa and Marwah',
      'description_ar': 'المشي بين الصفا والمروة',
      'icon': Icons.directions_walk,
      'route': '/rituals/sai',
    },
    {
      'title_en': 'Halq/Taqsir',
      'title_ar': 'الحلق/التقصير',
      'description_en': 'Shaving or trimming the hair',
      'description_ar': 'حلق أو تقصير الشعر',
      'icon': Icons.content_cut,
      'route': '/rituals/halq_taqsir',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'مناسك العمرة' : 'Umrah Rituals'),
      ),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header section
              Text(
                isArabic 
                    ? 'تعلم وتدرب على مناسك العمرة'
                    : 'Learn and practice Umrah rituals',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                isArabic 
                    ? 'اتبع الرسومات المتحركة التفاعلية والإرشادات خطوة بخطوة'
                    : 'Follow interactive animations and step-by-step guidance',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 24),
              
              // Rituals cards
              GridView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 0.8,
                ),
                itemCount: _rituals.length,
                itemBuilder: (context, index) {
                  final ritual = _rituals[index];
                  return Card(
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, ritual['route']);
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryGreen.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                ritual['icon'],
                                color: AppTheme.primaryGreen,
                                size: 40,
                              ),
                            ),
                            SizedBox(height: 16),
                            Text(
                              isArabic ? ritual['title_ar'] : ritual['title_en'],
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 8),
                            Text(
                              isArabic ? ritual['description_ar'] : ritual['description_en'],
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              
              SizedBox(height: 24),
              
              // Complete Umrah sequence card
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, '/rituals/complete_sequence');
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryGold.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.play_circle_outline,
                                color: AppTheme.primaryGold,
                                size: 30,
                              ),
                            ),
                            SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    isArabic ? 'تسلسل العمرة الكامل' : 'Complete Umrah Sequence',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    isArabic 
                                        ? 'شاهد جميع المناسك في تسلسلها الصحيح'
                                        : 'View all rituals in their correct sequence',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              
              SizedBox(height: 24),
              
              // Audio guidance section
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isArabic ? 'الإرشاد الصوتي' : 'Audio Guidance',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      SizedBox(height: 16),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryGreen.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.headset,
                            color: AppTheme.primaryGreen,
                          ),
                        ),
                        title: Text(
                          isArabic ? 'الإرشاد الصوتي للعمرة' : 'Umrah Audio Guide',
                        ),
                        subtitle: Text(
                          isArabic ? 'استمع إلى إرشادات خطوة بخطوة' : 'Listen to step-by-step instructions',
                        ),
                        trailing: Icon(Icons.play_arrow),
                        onTap: () {
                          // Play audio guidance
                        },
                      ),
                      Divider(),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryGreen.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.music_note,
                            color: AppTheme.primaryGreen,
                          ),
                        ),
                        title: Text(
                          isArabic ? 'تلاوة التلبية' : 'Talbiyah Recitation',
                        ),
                        subtitle: Text(
                          isArabic ? 'استمع وتعلم التلبية الصحيحة' : 'Listen and learn the correct Talbiyah',
                        ),
                        trailing: Icon(Icons.play_arrow),
                        onTap: () {
                          // Play Talbiyah audio
                        },
                      ),
                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 24),
              
              // Offline availability indicator
              Container(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.green),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle, color: Colors.green, size: 16),
                    SizedBox(width: 8),
                    Text(
                      isArabic ? 'جميع الرسومات المتحركة والصوت متاحة للاستخدام بدون إنترنت' : 'All animations and audio available for offline use',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
