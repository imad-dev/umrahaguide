import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class PlannerScreen extends StatefulWidget {
  const PlannerScreen({Key? key}) : super(key: key);

  @override
  _PlannerScreenState createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'المخطط الشخصي' : 'Personal Planner'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: [
            Tab(
              icon: Icon(Icons.calendar_today),
              text: isArabic ? 'الجدول الزمني' : 'Timeline',
            ),
            Tab(
              icon: Icon(Icons.schedule),
              text: isArabic ? 'الجدول اليومي' : 'Daily Schedule',
            ),
            Tab(
              icon: Icon(Icons.note_alt),
              text: isArabic ? 'ملاحظات' : 'Notes',
            ),
          ],
        ),
      ),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: TabBarView(
          controller: _tabController,
          children: [
            // Timeline Tab
            _buildTimelineTab(isArabic),
            
            // Daily Schedule Tab
            _buildDailyScheduleTab(isArabic),
            
            // Notes Tab
            _buildNotesTab(isArabic),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add new item based on current tab
          if (_tabController.index == 0) {
            // Add timeline event
          } else if (_tabController.index == 1) {
            // Add schedule item
          } else {
            // Add note
          }
        },
        backgroundColor: AppTheme.primaryGreen,
        child: Icon(Icons.add),
      ),
    );
  }
  
  Widget _buildTimelineTab(bool isArabic) {
    final timelineEvents = [
      {
        'title_en': 'Apply for Umrah Visa',
        'title_ar': 'التقدم بطلب للحصول على تأشيرة العمرة',
        'date': 'May 1, 2025',
        'completed': true,
      },
      {
        'title_en': 'Book Flights',
        'title_ar': 'حجز رحلات الطيران',
        'date': 'May 5, 2025',
        'completed': true,
      },
      {
        'title_en': 'Book Accommodation',
        'title_ar': 'حجز الإقامة',
        'date': 'May 10, 2025',
        'completed': true,
      },
      {
        'title_en': 'Prepare Travel Documents',
        'title_ar': 'تجهيز وثائق السفر',
        'date': 'May 15, 2025',
        'completed': true,
      },
      {
        'title_en': 'Pack Luggage',
        'title_ar': 'تعبئة الأمتعة',
        'date': 'May 22, 2025',
        'completed': true,
      },
      {
        'title_en': 'Departure to Saudi Arabia',
        'title_ar': 'المغادرة إلى المملكة العربية السعودية',
        'date': 'May 25, 2025',
        'completed': false,
      },
      {
        'title_en': 'Arrive in Makkah',
        'title_ar': 'الوصول إلى مكة',
        'date': 'May 26, 2025',
        'completed': false,
      },
      {
        'title_en': 'Perform Umrah',
        'title_ar': 'أداء العمرة',
        'date': 'May 27, 2025',
        'completed': false,
      },
      {
        'title_en': 'Visit Madinah',
        'title_ar': 'زيارة المدينة المنورة',
        'date': 'May 30, 2025',
        'completed': false,
      },
      {
        'title_en': 'Return Home',
        'title_ar': 'العودة إلى الوطن',
        'date': 'June 5, 2025',
        'completed': false,
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'الجدول الزمني للعمرة' : 'Umrah Timeline',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'تتبع رحلة العمرة الخاصة بك من البداية إلى النهاية'
                : 'Track your Umrah journey from start to finish',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Progress indicator
          LinearProgressIndicator(
            value: 0.5, // This would be dynamic based on completed events
            backgroundColor: Colors.grey[300],
            valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryGreen),
          ),
          SizedBox(height: 8),
          Text(
            isArabic ? '50% مكتمل' : '50% Complete',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Timeline events
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: timelineEvents.length,
            itemBuilder: (context, index) {
              final event = timelineEvents[index];
              final isCompleted = event['completed'] as bool;
              
              return Container(
                margin: EdgeInsets.only(bottom: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Timeline line and dot
                    Container(
                      width: 20,
                      height: 80,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Vertical line
                          if (index < timelineEvents.length - 1)
                            Positioned(
                              top: 20,
                              bottom: 0,
                              child: Container(
                                width: 2,
                                color: isCompleted ? AppTheme.primaryGreen : Colors.grey[300],
                              ),
                            ),
                          
                          // Dot
                          Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isCompleted ? AppTheme.primaryGreen : Colors.grey[300],
                              border: Border.all(
                                color: isCompleted ? AppTheme.primaryGreen : Colors.grey[300],
                                width: 2,
                              ),
                            ),
                            child: isCompleted
                                ? Icon(
                                    Icons.check,
                                    size: 12,
                                    color: Colors.white,
                                  )
                                : null,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16),
                    
                    // Event content
                    Expanded(
                      child: Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                isArabic ? event['title_ar'] as String : event['title_en'] as String,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: isCompleted ? AppTheme.primaryGreen : null,
                                  decoration: isCompleted ? TextDecoration.lineThrough : null,
                                ),
                              ),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(
                                    Icons.calendar_today,
                                    size: 14,
                                    color: Colors.grey[600],
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    event['date'] as String,
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
  
  Widget _buildDailyScheduleTab(bool isArabic) {
    final scheduleItems = [
      {
        'time': '04:30 AM',
        'title_en': 'Wake up for Fajr',
        'title_ar': 'الاستيقاظ لصلاة الفجر',
        'category': 'prayer',
      },
      {
        'time': '05:00 AM',
        'title_en': 'Fajr Prayer',
        'title_ar': 'صلاة الفجر',
        'category': 'prayer',
      },
      {
        'time': '07:00 AM',
        'title_en': 'Breakfast',
        'title_ar': 'وجبة الإفطار',
        'category': 'meal',
      },
      {
        'time': '09:00 AM',
        'title_en': 'Tawaf',
        'title_ar': 'الطواف',
        'category': 'ritual',
      },
      {
        'time': '10:30 AM',
        'title_en': 'Sa\'i',
        'title_ar': 'السعي',
        'category': 'ritual',
      },
      {
        'time': '12:30 PM',
        'title_en': 'Dhuhr Prayer',
        'title_ar': 'صلاة الظهر',
        'category': 'prayer',
      },
      {
        'time': '01:30 PM',
        'title_en': 'Lunch',
        'title_ar': 'وجبة الغداء',
        'category': 'meal',
      },
      {
        'time': '03:00 PM',
        'title_en': 'Rest',
        'title_ar': 'الراحة',
        'category': 'other',
      },
      {
        'time': '04:00 PM',
        'title_en': 'Asr Prayer',
        'title_ar': 'صلاة العصر',
        'category': 'prayer',
      },
      {
        'time': '05:30 PM',
        'title_en': 'Quran Reading',
        'title_ar': 'قراءة القرآن',
        'category': 'other',
      },
      {
        'time': '07:00 PM',
        'title_en': 'Maghrib Prayer',
        'title_ar': 'صلاة المغرب',
        'category': 'prayer',
      },
      {
        'time': '08:00 PM',
        'title_en': 'Dinner',
        'title_ar': 'وجبة العشاء',
        'category': 'meal',
      },
      {
        'time': '08:30 PM',
        'title_en': 'Isha Prayer',
        'title_ar': 'صلاة العشاء',
        'category': 'prayer',
      },
      {
        'time': '10:00 PM',
        'title_en': 'Sleep',
        'title_ar': 'النوم',
        'category': 'other',
      },
    ];
    
    Color getCategoryColor(String category) {
      switch (category) {
        case 'prayer':
          return AppTheme.primaryGreen;
        case 'ritual':
          return AppTheme.primaryGold;
        case 'meal':
          return Colors.orange;
        default:
          return Colors.grey;
      }
    }
    
    IconData getCategoryIcon(String category) {
      switch (category) {
        case 'prayer':
          return Icons.mosque;
        case 'ritual':
          return Icons.auto_awesome;
        case 'meal':
          return Icons.restaurant;
        default:
          return Icons.event_note;
      }
    }
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'الجدول اليومي' : 'Daily Schedule',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'خطط يومك بشكل فعال أثناء رحلة العمرة'
                : 'Plan your day effectively during your Umrah journey',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 16),
          
          // Date selector
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.calendar_today, color: AppTheme.primaryGreen),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isArabic ? 'التاريخ' : 'Date',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                        Text(
                          'Friday, May 23, 2025',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back_ios, size: 16),
                        onPressed: () {
                          // Previous day
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.arrow_forward_ios, size: 16),
                        onPressed: () {
                          // Next day
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          
          // Schedule items
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: scheduleItems.length,
            itemBuilder: (context, index) {
              final item = scheduleItems[index];
              final category = item['category'] as String;
              final categoryColor = getCategoryColor(category);
              final categoryIcon = getCategoryIcon(category);
              
              return Container(
                margin: EdgeInsets.only(bottom: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Time column
                    Container(
                      width: 80,
                      child: Text(
                        item['time'] as String,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[700],
                        ),
                      ),
                    ),
                    
                    // Timeline dot and line
                    Container(
                      width: 20,
                      height: 60,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Vertical line
                          if (index < scheduleItems.length - 1)
                            Positioned(
                              top: 20,
                              bottom: 0,
                              child: Container(
                                width: 2,
                                color: Colors.grey[300],
                              ),
                            ),
                          
                          // Dot
                          Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: categoryColor.withOpacity(0.2),
                              border: Border.all(
                                color: categoryColor,
                                width: 2,
                              ),
                            ),
                            child: Icon(
                              categoryIcon,
                              size: 12,
                              color: categoryColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16),
                    
                    // Event content
                    Expanded(
                      child: Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  isArabic ? item['title_ar'] as String : item['title_en'] as String,
                                  style: TextStyle(
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.edit, size: 16, color: Colors.grey),
                                onPressed: () {
                                  // Edit schedule item
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
  
  Widget _buildNotesTab(bool isArabic) {
    final notes = [
      {
        'title_en': 'Important Duas to Remember',
        'title_ar': 'أدعية مهمة للتذكر',
        'content_en': 'List of important duas for Tawaf and Sa\'i...',
        'content_ar': 'قائمة الأدعية المهمة للطواف والسعي...',
        'date': 'May 20, 2025',
      },
      {
        'title_en': 'Hotel Information',
        'title_ar': 'معلومات الفندق',
        'content_en': 'Hotel address, confirmation number, and contact details...',
        'content_ar': 'عنوان الفندق ورقم التأكيد وتفاصيل الاتصال...',
        'date': 'May 18, 2025',
      },
      {
        'title_en': 'Meeting Points with Group',
        'title_ar': 'نقاط الالتقاء مع المجموعة',
        'content_en': 'Meeting locations and times for group activities...',
        'content_ar': 'مواقع وأوقات الاجتماع للأنشطة الجماعية...',
        'date': 'May 15, 2025',
      },
      {
        'title_en': 'Shopping List',
        'title_ar': 'قائمة التسوق',
        'content_en': 'Items to buy in Makkah and Madinah...',
        'content_ar': 'الأشياء للشراء في مكة والمدينة...',
        'date': 'May 10, 2025',
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'ملاحظاتي' : 'My Notes',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'احتفظ بملاحظات وتذكيرات مهمة لرحلة العمرة'
                : 'Keep important notes and reminders for your Umrah journey',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Search bar
          TextField(
            decoration: InputDecoration(
              hintText: isArabic ? 'البحث في الملاحظات...' : 'Search notes...',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: AppTheme.primaryGreen),
              ),
              filled: true,
              fillColor: Colors.grey[100],
            ),
          ),
          SizedBox(height: 24),
          
          // Notes list
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: notes.length,
            itemBuilder: (context, index) {
              final note = notes[index];
              
              return Card(
                margin: EdgeInsets.only(bottom: 16),
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: InkWell(
                  onTap: () {
                    // View note details
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                isArabic ? note['title_ar'] as String : note['title_en'] as String,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            PopupMenuButton(
                              icon: Icon(Icons.more_vert),
                              itemBuilder: (context) => [
                                PopupMenuItem(
                                  child: Row(
                                    children: [
                                      Icon(Icons.edit, size: 16),
                                      SizedBox(width: 8),
                                      Text(isArabic ? 'تعديل' : 'Edit'),
                                    ],
                                  ),
                                  value: 'edit',
                                ),
                                PopupMenuItem(
                                  child: Row(
                                    children: [
                                      Icon(Icons.delete, size: 16),
                                      SizedBox(width: 8),
                                      Text(isArabic ? 'حذف' : 'Delete'),
                                    ],
                                  ),
                                  value: 'delete',
                                ),
                              ],
                              onSelected: (value) {
                                // Handle menu item selection
                              },
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        Text(
                          isArabic ? note['content_ar'] as String : note['content_en'] as String,
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[700],
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 16),
                        Row(
                          children: [
                            Icon(
                              Icons.calendar_today,
                              size: 14,
                              color: Colors.grey[600],
                            ),
                            SizedBox(width: 4),
                            Text(
                              note['date'] as String,
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
