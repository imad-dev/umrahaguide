import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class TravelKitScreen extends StatefulWidget {
  const TravelKitScreen({Key? key}) : super(key: key);

  @override
  _TravelKitScreenState createState() => _TravelKitScreenState();
}

class _TravelKitScreenState extends State<TravelKitScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'أدوات السفر' : 'Travel Toolkit'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: [
            Tab(
              icon: Icon(Icons.checklist),
              text: isArabic ? 'قائمة التعبئة' : 'Packing List',
            ),
            Tab(
              icon: Icon(Icons.access_time),
              text: isArabic ? 'أوقات الصلاة' : 'Prayer Times',
            ),
            Tab(
              icon: Icon(Icons.explore),
              text: isArabic ? 'القبلة' : 'Qibla',
            ),
            Tab(
              icon: Icon(Icons.map),
              text: isArabic ? 'الخرائط' : 'Maps',
            ),
          ],
        ),
      ),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: TabBarView(
          controller: _tabController,
          children: [
            // Packing List Tab
            _buildPackingListTab(isArabic),
            
            // Prayer Times Tab
            _buildPrayerTimesTab(isArabic),
            
            // Qibla Direction Tab
            _buildQiblaTab(isArabic),
            
            // Maps Tab
            _buildMapsTab(isArabic),
          ],
        ),
      ),
    );
  }
  
  Widget _buildPackingListTab(bool isArabic) {
    final categories = [
      {
        'title_en': 'Documents',
        'title_ar': 'الوثائق',
        'icon': Icons.description,
        'items': [
          {'name_en': 'Passport', 'name_ar': 'جواز السفر', 'checked': false},
          {'name_en': 'Visa', 'name_ar': 'تأشيرة', 'checked': false},
          {'name_en': 'Flight Tickets', 'name_ar': 'تذاكر الطيران', 'checked': false},
          {'name_en': 'Hotel Reservations', 'name_ar': 'حجوزات الفندق', 'checked': false},
          {'name_en': 'Travel Insurance', 'name_ar': 'تأمين السفر', 'checked': false},
          {'name_en': 'ID Cards', 'name_ar': 'بطاقات الهوية', 'checked': false},
        ],
      },
      {
        'title_en': 'Clothing',
        'title_ar': 'الملابس',
        'icon': Icons.checkroom,
        'items': [
          {'name_en': 'Ihram Garments (Men)', 'name_ar': 'ملابس الإحرام (للرجال)', 'checked': false},
          {'name_en': 'Prayer Clothes', 'name_ar': 'ملابس الصلاة', 'checked': false},
          {'name_en': 'Comfortable Shoes', 'name_ar': 'أحذية مريحة', 'checked': false},
          {'name_en': 'Socks', 'name_ar': 'جوارب', 'checked': false},
          {'name_en': 'Undergarments', 'name_ar': 'ملابس داخلية', 'checked': false},
          {'name_en': 'Light Jacket', 'name_ar': 'سترة خفيفة', 'checked': false},
        ],
      },
      {
        'title_en': 'Toiletries',
        'title_ar': 'مستلزمات النظافة',
        'icon': Icons.sanitizer,
        'items': [
          {'name_en': 'Unscented Soap', 'name_ar': 'صابون غير معطر', 'checked': false},
          {'name_en': 'Toothbrush & Toothpaste', 'name_ar': 'فرشاة أسنان ومعجون', 'checked': false},
          {'name_en': 'Shampoo', 'name_ar': 'شامبو', 'checked': false},
          {'name_en': 'Hand Sanitizer', 'name_ar': 'معقم اليدين', 'checked': false},
          {'name_en': 'Face Masks', 'name_ar': 'أقنعة الوجه', 'checked': false},
          {'name_en': 'Wet Wipes', 'name_ar': 'مناديل مبللة', 'checked': false},
        ],
      },
      {
        'title_en': 'Medications',
        'title_ar': 'الأدوية',
        'icon': Icons.medication,
        'items': [
          {'name_en': 'Prescription Medications', 'name_ar': 'الأدوية الموصوفة', 'checked': false},
          {'name_en': 'Pain Relievers', 'name_ar': 'مسكنات الألم', 'checked': false},
          {'name_en': 'Stomach Medicine', 'name_ar': 'دواء المعدة', 'checked': false},
          {'name_en': 'First Aid Kit', 'name_ar': 'حقيبة الإسعافات الأولية', 'checked': false},
          {'name_en': 'Bandages', 'name_ar': 'ضمادات', 'checked': false},
          {'name_en': 'Sunscreen', 'name_ar': 'واقي الشمس', 'checked': false},
        ],
      },
      {
        'title_en': 'Electronics',
        'title_ar': 'الإلكترونيات',
        'icon': Icons.devices,
        'items': [
          {'name_en': 'Mobile Phone', 'name_ar': 'هاتف محمول', 'checked': false},
          {'name_en': 'Chargers', 'name_ar': 'شواحن', 'checked': false},
          {'name_en': 'Power Bank', 'name_ar': 'بنك الطاقة', 'checked': false},
          {'name_en': 'Universal Adapter', 'name_ar': 'محول عالمي', 'checked': false},
          {'name_en': 'Headphones', 'name_ar': 'سماعات', 'checked': false},
        ],
      },
      {
        'title_en': 'Miscellaneous',
        'title_ar': 'متفرقات',
        'icon': Icons.more_horiz,
        'items': [
          {'name_en': 'Prayer Mat', 'name_ar': 'سجادة صلاة', 'checked': false},
          {'name_en': 'Quran', 'name_ar': 'القرآن الكريم', 'checked': false},
          {'name_en': 'Dua Books', 'name_ar': 'كتب الدعاء', 'checked': false},
          {'name_en': 'Money Belt', 'name_ar': 'حزام النقود', 'checked': false},
          {'name_en': 'Saudi Currency', 'name_ar': 'العملة السعودية', 'checked': false},
          {'name_en': 'Umbrella', 'name_ar': 'مظلة', 'checked': false},
          {'name_en': 'Water Bottle', 'name_ar': 'زجاجة ماء', 'checked': false},
        ],
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'قائمة التعبئة التفاعلية' : 'Interactive Packing Checklist',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'تأكد من تعبئة كل ما تحتاجه لرحلة عمرة ناجحة'
                : 'Make sure you pack everything you need for a successful Umrah journey',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Progress indicator
          LinearProgressIndicator(
            value: 0.0, // This would be dynamic based on checked items
            backgroundColor: Colors.grey[300],
            valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryGreen),
          ),
          SizedBox(height: 8),
          Text(
            isArabic ? '0% مكتمل' : '0% Complete',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Categories and items
          ...categories.map((category) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Category header
                Container(
                  margin: EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryGreen.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          category['icon'] as IconData,
                          color: AppTheme.primaryGreen,
                        ),
                      ),
                      SizedBox(width: 12),
                      Text(
                        isArabic ? category['title_ar'] as String : category['title_en'] as String,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Category items
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListView.separated(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: (category['items'] as List).length,
                    separatorBuilder: (context, index) => Divider(height: 1),
                    itemBuilder: (context, index) {
                      final item = (category['items'] as List)[index];
                      return CheckboxListTile(
                        title: Text(
                          isArabic ? item['name_ar'] as String : item['name_en'] as String,
                        ),
                        value: item['checked'] as bool,
                        activeColor: AppTheme.primaryGreen,
                        onChanged: (bool? value) {
                          setState(() {
                            item['checked'] = value;
                          });
                        },
                      );
                    },
                  ),
                ),
                SizedBox(height: 24),
              ],
            );
          }).toList(),
          
          // Add custom item button
          ElevatedButton.icon(
            onPressed: () {
              // Show dialog to add custom item
            },
            icon: Icon(Icons.add),
            label: Text(isArabic ? 'إضافة عنصر مخصص' : 'Add Custom Item'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGreen,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildPrayerTimesTab(bool isArabic) {
    // Sample prayer times data
    final prayerTimes = [
      {'name_en': 'Fajr', 'name_ar': 'الفجر', 'time': '04:35 AM'},
      {'name_en': 'Sunrise', 'name_ar': 'الشروق', 'time': '06:05 AM'},
      {'name_en': 'Dhuhr', 'name_ar': 'الظهر', 'time': '12:20 PM'},
      {'name_en': 'Asr', 'name_ar': 'العصر', 'time': '03:45 PM'},
      {'name_en': 'Maghrib', 'name_ar': 'المغرب', 'time': '06:35 PM'},
      {'name_en': 'Isha', 'name_ar': 'العشاء', 'time': '08:05 PM'},
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'أوقات الصلاة' : 'Prayer Times',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'أوقات الصلاة لموقعك الحالي'
                : 'Prayer times for your current location',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 16),
          
          // Location card
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.location_on, color: AppTheme.primaryGreen),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isArabic ? 'الموقع الحالي' : 'Current Location',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                        Text(
                          'Makkah, Saudi Arabia',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      // Change location
                    },
                    child: Text(
                      isArabic ? 'تغيير' : 'Change',
                      style: TextStyle(
                        color: AppTheme.primaryGreen,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          
          // Date card
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.calendar_today, color: AppTheme.primaryGreen),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isArabic ? 'التاريخ' : 'Date',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                        Text(
                          'Friday, May 23, 2025',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    '15 Shawwal 1446',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          
          // Prayer times list
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: prayerTimes.length,
              separatorBuilder: (context, index) => Divider(height: 1),
              itemBuilder: (context, index) {
                final prayer = prayerTimes[index];
                final isNext = index == 2; // For demonstration, Dhuhr is the next prayer
                
                return ListTile(
                  title: Text(
                    isArabic ? prayer['name_ar'] as String : prayer['name_en'] as String,
                    style: TextStyle(
                      fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        prayer['time'] as String,
                        style: TextStyle(
                          fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                          color: isNext ? AppTheme.primaryGreen : null,
                        ),
                      ),
                      if (isNext)
                        Container(
                          margin: EdgeInsets.only(left: 8),
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryGreen,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            isArabic ? 'التالي' : 'NEXT',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 24),
          
          // Notification settings
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isArabic ? 'إعدادات الإشعارات' : 'Notification Settings',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 16),
                  SwitchListTile(
                    title: Text(isArabic ? 'تنبيهات الصلاة' : 'Prayer Alerts'),
                    subtitle: Text(
                      isArabic ? 'تلقي إشعارات قبل كل صلاة' : 'Receive notifications before each prayer',
                    ),
                    value: true,
                    activeColor: AppTheme.primaryGreen,
                    onChanged: (bool value) {
                      // Toggle prayer alerts
                    },
                  ),
                  SwitchListTile(
                    title: Text(isArabic ? 'صوت الأذان' : 'Adhan Sound'),
                    subtitle: Text(
                      isArabic ? 'تشغيل صوت الأذان عند وقت الصلاة' : 'Play adhan sound at prayer time',
                    ),
                    value: true,
                    activeColor: AppTheme.primaryGreen,
                    onChanged: (bool value) {
                      // Toggle adhan sound
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildQiblaTab(bool isArabic) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Qibla compass placeholder
          Container(
            width: 250,
            height: 250,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey[200],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Compass markings
                Container(
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey),
                  ),
                  child: Center(
                    child: Text(
                      'N',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                
                // Qibla direction arrow
                Transform.rotate(
                  angle: 0.7, // This would be dynamic based on actual direction
                  child: Container(
                    width: 200,
                    height: 10,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, AppTheme.primaryGreen],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                    ),
                  ),
                ),
                
                // Center point
                Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.primaryGreen,
                  ),
                ),
                
                // Kaaba icon
                Positioned(
                  right: 30,
                  child: Icon(
                    Icons.account_balance,
                    color: AppTheme.primaryGreen,
                    size: 30,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 40),
          
          // Direction information
          Text(
            isArabic ? 'اتجاه القبلة' : 'Qibla Direction',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            '125° SE',
            style: TextStyle(
              fontSize: 18,
              color: AppTheme.primaryGreen,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 24),
          
          // Instructions
          Container(
            padding: EdgeInsets.all(16),
            margin: EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text(
                  isArabic 
                      ? 'للحصول على قراءة دقيقة:'
                      : 'For accurate reading:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  isArabic 
                      ? '1. ضع هاتفك على سطح مستوٍ\n2. ابتعد عن الأجسام المعدنية\n3. قم بمعايرة البوصلة إذا لزم الأمر'
                      : '1. Place your phone on a flat surface\n2. Stay away from metal objects\n3. Calibrate compass if needed',
                  style: TextStyle(
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 24),
          
          // Calibrate button
          ElevatedButton.icon(
            onPressed: () {
              // Calibrate compass
            },
            icon: Icon(Icons.refresh),
            label: Text(isArabic ? 'معايرة البوصلة' : 'Calibrate Compass'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGreen,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildMapsTab(bool isArabic) {
    final mapLocations = [
      {
        'title_en': 'Makkah Map',
        'title_ar': 'خريطة مكة',
        'description_en': 'Interactive map of Makkah and the Grand Mosque',
        'description_ar': 'خريطة تفاعلية لمكة والمسجد الحرام',
        'icon': Icons.location_city,
      },
      {
        'title_en': 'Madinah Map',
        'title_ar': 'خريطة المدينة',
        'description_en': 'Interactive map of Madinah and the Prophet\'s Mosque',
        'description_ar': 'خريطة تفاعلية للمدينة والمسجد النبوي',
        'icon': Icons.mosque,
      },
      {
        'title_en': 'Grand Mosque Interior',
        'title_ar': 'داخل المسجد الحرام',
        'description_en': 'Detailed map of the Grand Mosque interior',
        'description_ar': 'خريطة مفصلة لداخل المسجد الحرام',
        'icon': Icons.map,
      },
      {
        'title_en': 'Prophet\'s Mosque Interior',
        'title_ar': 'داخل المسجد النبوي',
        'description_en': 'Detailed map of the Prophet\'s Mosque interior',
        'description_ar': 'خريطة مفصلة لداخل المسجد النبوي',
        'icon': Icons.map,
      },
      {
        'title_en': 'Important Landmarks',
        'title_ar': 'المعالم المهمة',
        'description_en': 'Historical and religious sites in Makkah and Madinah',
        'description_ar': 'المواقع التاريخية والدينية في مكة والمدينة',
        'icon': Icons.place,
      },
      {
        'title_en': 'Transportation Routes',
        'title_ar': 'طرق المواصلات',
        'description_en': 'Public transportation and walking routes',
        'description_ar': 'وسائل النقل العام وطرق المشي',
        'icon': Icons.directions_bus,
      },
    ];
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isArabic ? 'الخرائط بدون إنترنت' : 'Offline Maps',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            isArabic 
                ? 'خرائط تفصيلية لمكة والمدينة متاحة بدون إنترنت'
                : 'Detailed maps of Makkah and Madinah available offline',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 24),
          
          // Map preview (placeholder)
          Container(
            height: 200,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Icon(
                Icons.map,
                size: 80,
                color: Colors.grey[500],
              ),
            ),
          ),
          SizedBox(height: 24),
          
          // Available maps
          Text(
            isArabic ? 'الخرائط المتاحة' : 'Available Maps',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          
          // Map list
          ListView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: mapLocations.length,
            itemBuilder: (context, index) {
              final map = mapLocations[index];
              return Card(
                margin: EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
                child: ListTile(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryGreen.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      map['icon'] as IconData,
                      color: AppTheme.primaryGreen,
                    ),
                  ),
                  title: Text(
                    isArabic ? map['title_ar'] as String : map['title_en'] as String,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    isArabic ? map['description_ar'] as String : map['description_en'] as String,
                  ),
                  trailing: Icon(
                    isArabic ? Icons.arrow_back_ios : Icons.arrow_forward_ios,
                    size: 16,
                  ),
                  onTap: () {
                    // Open selected map
                  },
                ),
              );
            },
          ),
          
          SizedBox(height: 24),
          
          // Download status
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.green),
            ),
            child: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.green),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isArabic ? 'جميع الخرائط متاحة للاستخدام بدون إنترنت' : 'All maps available for offline use',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        isArabic 
                            ? 'آخر تحديث: 23 مايو 2025'
                            : 'Last updated: May 23, 2025',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: () {
                    // Update maps
                  },
                  child: Text(
                    isArabic ? 'تحديث' : 'Update',
                    style: TextStyle(
                      color: AppTheme.primaryGreen,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
