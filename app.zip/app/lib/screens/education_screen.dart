import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';

class EducationScreen extends StatefulWidget {
  const EducationScreen({Key? key}) : super(key: key);

  @override
  _EducationScreenState createState() => _EducationScreenState();
}

class _EducationScreenState extends State<EducationScreen> {
  final List<Map<String, dynamic>> _educationalModules = [
    {
      'title_en': 'Introduction to Umrah',
      'title_ar': 'مقدمة عن العمرة',
      'icon': Icons.info_outline,
      'route': '/education/introduction',
    },
    {
      'title_en': 'Ihram',
      'title_ar': 'الإحرام',
      'icon': Icons.person_outline,
      'route': '/education/ihram',
    },
    {
      'title_en': 'Tawaf',
      'title_ar': 'الطواف',
      'icon': Icons.sync,
      'route': '/education/tawaf',
    },
    {
      'title_en': 'Sa\'i',
      'title_ar': 'السعي',
      'icon': Icons.directions_walk,
      'route': '/education/sai',
    },
    {
      'title_en': 'Halq/Taqsir',
      'title_ar': 'الحلق/التقصير',
      'icon': Icons.content_cut,
      'route': '/education/halq_taqsir',
    },
    {
      'title_en': 'Visiting Madinah',
      'title_ar': 'زيارة المدينة المنورة',
      'icon': Icons.location_city,
      'route': '/education/madinah',
    },
    {
      'title_en': 'Duas and Supplications',
      'title_ar': 'الأدعية والأذكار',
      'icon': Icons.favorite_outline,
      'route': '/education/duas',
    },
    {
      'title_en': 'Travel Essentials',
      'title_ar': 'أساسيات السفر',
      'icon': Icons.luggage,
      'route': '/education/travel_essentials',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text(isArabic ? 'الوحدات التعليمية' : 'Educational Modules'),
      ),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header section
              Text(
                isArabic 
                    ? 'تعلم كل ما تحتاج معرفته عن العمرة'
                    : 'Learn everything you need to know about Umrah',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                isArabic 
                    ? 'اختر وحدة تعليمية للبدء في رحلة التعلم الخاصة بك'
                    : 'Select an educational module to begin your learning journey',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 24),
              
              // Educational modules list
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: _educationalModules.length,
                itemBuilder: (context, index) {
                  final module = _educationalModules[index];
                  return Card(
                    margin: EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 2,
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      leading: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryGreen.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          module['icon'],
                          color: AppTheme.primaryGreen,
                        ),
                      ),
                      title: Text(
                        isArabic ? module['title_ar'] : module['title_en'],
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      trailing: Icon(
                        isArabic ? Icons.arrow_back_ios : Icons.arrow_forward_ios,
                        size: 16,
                      ),
                      onTap: () {
                        Navigator.pushNamed(context, module['route']);
                      },
                    ),
                  );
                },
              ),
              
              SizedBox(height: 24),
              
              // Learning progress section
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isArabic ? 'تقدم التعلم الخاص بك' : 'Your Learning Progress',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: 12),
                    LinearProgressIndicator(
                      value: 0.0, // This would be dynamic based on user progress
                      backgroundColor: Colors.grey[300],
                      valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryGreen),
                    ),
                    SizedBox(height: 8),
                    Text(
                      isArabic ? 'أكمل الوحدات التعليمية لتتبع تقدمك' : 'Complete educational modules to track your progress',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              
              SizedBox(height: 24),
              
              // Offline availability indicator
              Container(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.green),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle, color: Colors.green, size: 16),
                    SizedBox(width: 8),
                    Text(
                      isArabic ? 'جميع الوحدات متاحة للاستخدام بدون إنترنت' : 'All modules available for offline use',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
