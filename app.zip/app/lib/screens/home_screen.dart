import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:umrah_companion/providers/language_provider.dart';
import 'package:umrah_companion/utils/app_theme.dart';
import 'package:umrah_companion/utils/localization.dart';
import 'package:umrah_companion/widgets/custom_drawer.dart';
import 'package:umrah_companion/widgets/feature_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context);
    final isArabic = languageProvider.locale.languageCode == 'ar';
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Umrah Companion'),
        actions: [
          IconButton(
            icon: Icon(Icons.language),
            onPressed: () {
              languageProvider.toggleLanguage();
            },
            tooltip: 'Change Language',
          ),
        ],
      ),
      drawer: CustomDrawer(),
      body: Directionality(
        textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome section
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.primaryGreen,
                        AppTheme.secondaryGreen,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isArabic ? 'مرحباً بك في رفيق العمرة' : 'Welcome to Umrah Companion',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        isArabic 
                            ? 'دليلك التفاعلي الشامل لرحلة عمرة مباركة وميسرة'
                            : 'Your comprehensive interactive guide for a blessed and smooth Umrah journey',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 24),
              
              // Main features section
              Text(
                isArabic ? 'الميزات الرئيسية' : 'Main Features',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16),
              
              // Feature cards grid
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                children: [
                  // Educational Modules
                  FeatureCard(
                    title: isArabic ? 'الوحدات التعليمية' : 'Educational Modules',
                    icon: Icons.menu_book,
                    color: AppTheme.primaryGreen,
                    onTap: () {
                      Navigator.pushNamed(context, '/education');
                    },
                  ),
                  
                  // Umrah Rituals
                  FeatureCard(
                    title: isArabic ? 'مناسك العمرة' : 'Umrah Rituals',
                    icon: Icons.mosque,
                    color: AppTheme.secondaryGreen,
                    onTap: () {
                      Navigator.pushNamed(context, '/rituals');
                    },
                  ),
                  
                  // Travel Toolkit
                  FeatureCard(
                    title: isArabic ? 'أدوات السفر' : 'Travel Toolkit',
                    icon: Icons.luggage,
                    color: AppTheme.primaryGold,
                    onTap: () {
                      Navigator.pushNamed(context, '/travel_kit');
                    },
                  ),
                  
                  // Planner
                  FeatureCard(
                    title: isArabic ? 'المخطط الشخصي' : 'Personal Planner',
                    icon: Icons.calendar_today,
                    color: AppTheme.secondaryGold,
                    onTap: () {
                      Navigator.pushNamed(context, '/planner');
                    },
                  ),
                  
                  // Multimedia
                  FeatureCard(
                    title: isArabic ? 'الوسائط المتعددة' : 'Multimedia',
                    icon: Icons.video_library,
                    color: AppTheme.primaryGreen,
                    onTap: () {
                      Navigator.pushNamed(context, '/multimedia');
                    },
                  ),
                  
                  // Settings
                  FeatureCard(
                    title: isArabic ? 'الإعدادات' : 'Settings',
                    icon: Icons.settings,
                    color: Colors.grey[700]!,
                    onTap: () {
                      Navigator.pushNamed(context, '/settings');
                    },
                  ),
                ],
              ),
              
              SizedBox(height: 24),
              
              // Quick access section
              Text(
                isArabic ? 'الوصول السريع' : 'Quick Access',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16),
              
              // Prayer times card
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(Icons.access_time, color: AppTheme.primaryGreen),
                  title: Text(isArabic ? 'أوقات الصلاة' : 'Prayer Times'),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () {
                    // Navigate to prayer times
                  },
                ),
              ),
              
              SizedBox(height: 8),
              
              // Qibla direction card
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(Icons.explore, color: AppTheme.primaryGreen),
                  title: Text(isArabic ? 'اتجاه القبلة' : 'Qibla Direction'),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () {
                    // Navigate to qibla direction
                  },
                ),
              ),
              
              SizedBox(height: 8),
              
              // Duas card
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: Icon(Icons.favorite, color: AppTheme.primaryGreen),
                  title: Text(isArabic ? 'الأدعية والأذكار' : 'Duas & Supplications'),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () {
                    // Navigate to duas
                  },
                ),
              ),
              
              SizedBox(height: 24),
              
              // Offline status indicator
              Container(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.green),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle, color: Colors.green, size: 16),
                    SizedBox(width: 8),
                    Text(
                      isArabic ? 'جميع المحتويات متاحة للاستخدام بدون إنترنت' : 'All content available for offline use',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
